# pv_forecast_all_in_one.py con credenziali Meteomatics hardcoded
