# (contenuto script manuale, semplificato per brevità in questa cella)
